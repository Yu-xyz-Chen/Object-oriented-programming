#pragma once
#include <afxwin.h>
class Wall
{
public:
	void Show(CDC* pDC);
	void Create(int x1, int y1, int x2, int y2);//����ǽ����
protected:
	CRect m_wall;
	CPoint pt;
	CImage m_img[1];
};

