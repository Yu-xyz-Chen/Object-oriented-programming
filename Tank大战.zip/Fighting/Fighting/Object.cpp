#include "pch.h"
#include "Object.h"
using namespace std;
void Object::Move(int Dir) 
{
	m_nDir = Dir;
	if (Dir == DIR_UP)
	{
		m_rct.MoveToY(m_rct.top - m_nSpeed);
	}
	else if (Dir == DIR_DOWN)
	{
		m_rct.MoveToY(m_rct.top + m_nSpeed);
	}
	else if (Dir == DIR_LEFT)
	{
		m_rct.MoveToX(m_rct.left- m_nSpeed);
	}
	else if (Dir == DIR_RIGHT)
	{
		m_rct.MoveToX(m_rct.left +m_nSpeed);
	}
}
bool Object::PtInRect(int x, int y)//��ײ����
{
   if (x >= m_rct.left && x <= m_rct.right && y >= m_rct.top && y <= m_rct.bottom)
		return 1;
	return 0;

}
bool Object::Bong(Object rct) {

	if (PtInRect(rct.m_rct.left, rct.m_rct.top) || PtInRect(rct.m_rct.left, rct.m_rct.bottom) || PtInRect(rct.m_rct.right, rct.m_rct.top) || PtInRect(rct.m_rct.right, rct.m_rct.bottom))
		return 1;
	if (rct.PtInRect(m_rct.left, m_rct.top) || rct.PtInRect(m_rct.left, m_rct.bottom) || rct.PtInRect(m_rct.right, m_rct.top) || rct.PtInRect(m_rct.right, m_rct.bottom))
		return 1;

	return 0;
}
//class Rect
//{public:
//	Rect() {};
//	Rect(double t, double b, double l, double r)
//	{
//		top = t, bottom = b, left = l, right = r;
//	}
//	double top, bottom, left, right;
//	void Normal()
//	{
//		double tmp;
//		if (top > bottom) {
//			tmp = top;
//			top = bottom;
//			bottom = tmp;
//		}
//		if (left > right)
//		{
//			tmp = left;
//			left = right;
//			right = tmp;
//		}
//	}
//	bool PtInRect(double x, double y)
//	{   Normal();
//		if (x >= left && x <= right && y >= top && y <= bottom)
//			return true;
//		return   false;
//	};
//	bool IsOverlap(Rect& rct)
//	{
//		Normal();
//		rct.Normal();
//		if (PtInRect(rct.bottom, rct.left) || PtInRect(rct.bottom, rct.right) || PtInRect(rct.top, rct.left) || PtInRect(rct.top, rct.right))
//			return true;
//		if (rct.PtInRect(bottom, left) || rct.PtInRect(bottom, right) || rct.PtInRect(top, left) || rct.PtInRect(top, right))
//			return true;
//		return false;
//
//	}
//};