#pragma once
#include "Object.h"
#include"Shell.h"
#include"EShell.h"
#include<vector>
using namespace std;
class ETank :public Object
{
public:
	ETank(int suiji);
	~ETank();
	void Show(CDC* pDC);
	ETank ECreate(CRect rct, int suiji);
	EShell EFire();
};



