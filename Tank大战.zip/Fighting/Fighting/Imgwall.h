#pragma once
#include "Wall.h"

class Imgwall :
	public Wall
{
protected:
	CImage m_img;
public:
	void Show(CDC* pDC);
    bool LoadImg();
};

