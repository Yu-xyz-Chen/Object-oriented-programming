#pragma once
#include "Object.h"
class EShell :public Object
{
public:
	EShell() {}
	~EShell() {};
public:
	void Show(CDC* pDC);
	void Create(CPoint pos, int nDir, int nSpeed);
protected:
	void UpdatePos();
	DWORD m_time;
	CRect m_Rct;
};

