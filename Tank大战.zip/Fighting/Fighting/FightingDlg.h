﻿
// FightingDlg.h: 头文件
//

#pragma once
#include "tank.h"
#include"Shell.h"
#include<vector>
#include"Wall.h"
#include"ETank.h"
#include"Img.h"
#include"Imgwall.h"
#include"EShell.h"
#include "ImgEtank.h"
using namespace std;

// CFightingDlg 对话框
class CFightingDlg : public CDialogEx
{
// 构造
public:
	CFightingDlg(CWnd* pParent = nullptr);	// 标准构造函数

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_FIGHTING_DIALOG };
#endif
    protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 支持

	Tank m_MyTank;
	Wall m_Wall;
	vector<Shell>m_vecShell;
	vector<ETank>e_Tank;
	vector<Wall>wall;
	int suiji = 0;
	int suijimax = 10;//坦克最多有10个
	vector<EShell>m_vecEShell;
	Img imgshow;
// 实现
protected:
	HICON m_hIcon;
	Img m_tank;
	Imgwall m_wall;
	// 生成的消息映射函数
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
//	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
};
