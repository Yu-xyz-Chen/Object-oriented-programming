#include "pch.h"
#include "ImgEtank.h"
//void ImgEtank::Show(CDC* pDC)
//{
//	if (!m_img.IsNull())
//	{
//		CRect rct(etank.CenterPoint().x - 15, etank.CenterPoint().y - 15, etank.CenterPoint().x + 15, etank.CenterPoint().y + 15);
//		m_img.Draw(pDC->GetSafeHdc(), rct, Gdiplus::InterpolationModeHighQuality);
//
//
//	}
//
//}
//bool ImgEtank::LoadImg()
//{
//	m_img.Load(L"C:\\Users\\86183\\Desktop\\E��.jpg");
//	if (m_img.IsNull())
//		return false;
//	return true;
//}