#pragma once
#include <afxwin.h>
#include <xkeycheck.h>
const int DIR_UP = 0;
const int DIR_DOWN = 1;
const int DIR_LEFT = 2;
const int DIR_RIGHT = 3;
class Object
{
public:
	virtual void Show(CDC* pDC) {};
	void Create(CRect rct) { m_rct = rct; };
	CRect GetPos() { return m_rct; };
	virtual void Move( int Dir);
	bool flag1 = true;
	int m_nDir;
	bool PtInRect(int x, int y);
	bool Bong(Object o);
protected:
	CRect m_rct;

	int m_nSpeed;
	CImage* m_pImg;
};

