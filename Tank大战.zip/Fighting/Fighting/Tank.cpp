#include "pch.h"
#include "Tank.h"
#include<MMSystem.h>
#pragma comment(lib,"winmm.lib")

Tank::Tank() {
	m_rct = CRect(0, 0, 30, 30);//̹�˳�ʼ����
	m_nDir = 3;
	m_nSpeed = 2;//�ٶ�;
}
Tank::~Tank() {

}
void Tank::Show(CDC* pDC)
{
	pDC->Rectangle(m_rct);	
	pDC->MoveTo(m_rct.CenterPoint());
	if (m_nDir == DIR_UP)
		pDC->LineTo(m_rct.CenterPoint().x, m_rct.CenterPoint().y - 20);
	else if(m_nDir == DIR_DOWN)
		pDC->LineTo(m_rct.CenterPoint().x, m_rct.CenterPoint().y + 20);
    else if(m_nDir == DIR_LEFT)
	pDC->LineTo(m_rct.CenterPoint().x-20, m_rct.CenterPoint().y );
	else if(m_nDir == DIR_RIGHT)
	pDC->LineTo(m_rct.CenterPoint().x+20, m_rct.CenterPoint().y );//���ݷ���ͬ��������Ͳ����

}

Shell Tank::Fire()
{
	Shell sh;
	CPoint pt = m_rct.CenterPoint();
	sh.Create(pt, m_nDir, m_nSpeed * 50);//�ӵ��������ٶ�
	CString strFileName;
	TCHAR cPath[1024];
	GetModuleFileName(NULL, cPath, 1024);
	strFileName = cPath;
	CString strSound = strFileName.Left(strFileName.ReverseFind('\\') + 1) + L"fire.wav";
	PlaySound(strSound, 0, SND_FILENAME | SND_ASYNC);

	return sh;
}