#define _CRT_RAND_S
#include "pch.h"
#include "ETank.h"
#include<time.h>
#include"EShell.h"

ETank::ETank(int suiji) {
	m_rct = CRect(suiji * 30+90, 90 ,suiji * 30+120, 120);
	m_nDir = 3;
	m_nSpeed = 1;
}
ETank::~ETank() {

}
void ETank::Show(CDC* pDC) {
	CPen pen(PS_SOLID, 2, RGB(0, 0, 255));   //�������ʣ����ʷ����ɫ
	CPen* poldPen = pDC->SelectObject(&pen);
	pDC->Rectangle(m_rct);
	pDC->MoveTo(m_rct.CenterPoint());
    if (m_nDir == DIR_UP)
		pDC->LineTo(m_rct.CenterPoint().x, m_rct.CenterPoint().y - 25);
	else if (m_nDir == DIR_DOWN)
		pDC->LineTo(m_rct.CenterPoint().x, m_rct.CenterPoint().y + 25);
	else if (m_nDir == DIR_LEFT)
		pDC->LineTo(m_rct.CenterPoint().x - 25, m_rct.CenterPoint().y);
	else if (m_nDir == DIR_RIGHT)
		pDC->LineTo(m_rct.CenterPoint().x + 25, m_rct.CenterPoint().y);
	//pDC->SelectObject(poldPen); //�ָ�����
}

EShell ETank::EFire() {
	EShell sh;
	CPoint pt = m_rct.CenterPoint();
	sh.Create(pt, m_nDir, m_nSpeed * 50);
    return sh;
}
ETank ETank::ECreate(CRect rct, int suiji) {
	m_rct = rct;
	ETank t(suiji);
	return t;
}