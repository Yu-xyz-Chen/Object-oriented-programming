#include "pch.h"
#include "Img.h"
#include "Object.h"

bool Img::LoadImg(int nDir) {
	if (nDir == DIR_UP) {
		if (!m_img[0].IsNull()) {
			m_img[0].Destroy();
		}
		m_img[0].Load(L"p2tankU.gif");
		if (m_img[0].IsNull())
			return false;
	}
	if (nDir == DIR_DOWN) {
		if (!m_img[1].IsNull())
			m_img[1].Destroy();
		m_img[1].Load(L"p2tankD.gif");
		if (m_img[1].IsNull())
			return false;
	}
	if (nDir == DIR_LEFT) {
		if (!m_img[2].IsNull())
			m_img[2].Destroy();
		m_img[2].Load(L"p2tankL.gif");
		if (m_img[2].IsNull())
			return false;
	}
	if (nDir == DIR_RIGHT) {
		if (!m_img[3].IsNull())
			m_img[3].Destroy();
		m_img[3].Load(L"p2tankR.gif");
		if (m_img[3].IsNull())
			return false;
	}
	return true;
}

void Img::ShowImg(CDC* pDC, int x, int y, int nSize, int nDir) {
	if (nDir == DIR_UP) {
		m_img[0].Draw(pDC->GetSafeHdc(), x, y, nSize, nSize);
	}
	if (nDir == DIR_DOWN) {
		
		m_img[1].Draw(pDC->GetSafeHdc(), x, y, nSize, nSize);
	}
	if (nDir == DIR_LEFT) {
		
		m_img[2].Draw(pDC->GetSafeHdc(), x, y, nSize, nSize);
	}
	if (nDir == DIR_RIGHT) {
		
		m_img[3].Draw(pDC->GetSafeHdc(), x, y, nSize, nSize);
	}
}