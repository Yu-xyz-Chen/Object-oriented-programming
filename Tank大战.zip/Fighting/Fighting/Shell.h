#pragma once
#include "Object.h"
class Shell :public Object
{
public:
	Shell() {}
	~Shell() {};
public:
	void Show(CDC* pDC);
	void Create(CPoint pos, int nDir, int nSpeed);
protected:
	void UpdatePos();
protected:
	DWORD m_time;
	CRect m_iniRct;

};

