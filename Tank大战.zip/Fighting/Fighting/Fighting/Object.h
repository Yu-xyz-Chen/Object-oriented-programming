#pragma once
const int DIR_UP = 0;
const int DIR_DOWN = 1;
const int DIR_LEFT = 2;
const int DIR_RIGHT = 3;

class Object
{
public:
	
	void Show(CDC* pDC);
	void Create(CRect rct) { m_rct = rct; };
	CRect GetPos() { return m_rct; };
	void Move (int Dir);
	int m_nDir;
protected:
	CRect m_rct;
	int m_nSpeed;
	CImage* m_pImg;
};

