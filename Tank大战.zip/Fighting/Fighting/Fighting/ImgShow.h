#pragma once

class ImgShow
{
public:
	CImage m_img[4];
	void ShowImg(CDC* pDC, int x, int y, int nSize, int nDir);
	bool LoadImg(int nDir);
};

