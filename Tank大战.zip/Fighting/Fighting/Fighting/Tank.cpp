#include "pch.h"
#include "Tank.h"
//��������
#include<MMSystem.h>
#include<vector>
#pragma comment(lib,"winmm.lib")

Tank::Tank() {
	m_rct = CRect(0, 0, 30, 30);
	m_nDir = 3;
	m_nSpeed = 1;
}

Tank::~Tank() {

}

void Tank::Show(CDC* pDC) {
	CRect n_rct;
	int nsize = 30;
	pDC->Rectangle(m_rct);
	//pDC->MoveTo(m_rct.CenterPoint());
	if (m_nDir == DIR_UP) {
		/*pDC->LineTo(m_rct.CenterPoint().x, m_rct.CenterPoint().y - 20);*/

		n_rct = m_rct;
		m_img[0].Draw(pDC->GetSafeHdc(), 0, 0, 2 * nsize, 2 * nsize);
	}
	else if (m_nDir == DIR_DOWN) {
		pDC->LineTo(m_rct.CenterPoint().x, m_rct.CenterPoint().y + 20);
		/*n_rct = m_rct;
		m_img[1].Draw(pDC->GetSafeHdc(), 0, 0, 2 * nsize, 2 * nsize);*/
	}
	else if (m_nDir == DIR_LEFT) {
		pDC->LineTo(m_rct.CenterPoint().x - 20, m_rct.CenterPoint().y);
		/*n_rct = m_rct;
		m_img[2].Draw(pDC->GetSafeHdc(), 0, 0, 2 * nsize, 2 * nsize);*/
	}
	else if (m_nDir == DIR_RIGHT) {
		pDC->LineTo(m_rct.CenterPoint().x + 20, m_rct.CenterPoint().y);
		/*n_rct = m_rct;
		m_img[3].Draw(pDC->GetSafeHdc(), 0, 0, 2 * nsize, 2 * nsize);*/
	}
}


Shell Tank::Fire() {
	Shell sh;
	CPoint pt = m_rct.CenterPoint();
	sh.Create(pt, m_nDir, m_nSpeed * 50);//�ڵ���ʼλ����̹��һ�£����з�����̹�˿��ڷ���һ�£��ٶȱ�̹�˿�

	//���ſ�������
	CString strFileName;
	TCHAR cPath[1024];
	GetModuleFileName(NULL, cPath, 1024);//��ȡ��ǰexe���ڵ�Ŀ¼
	strFileName = cPath;
	CString strSound = strFileName.Left(strFileName.ReverseFind('\\') + 1) + L"fire.wav";//��ȡ�����ļ�����
	PlaySound(strSound, 0, SND_FILENAME | SND_ASYNC);//��������

	return sh;
}

void Object::Move(int Dir)
{
	m_nDir = Dir;
	if (Dir == DIR_UP)//up
	{
		m_rct.MoveToY(m_rct.top - m_nSpeed);
	}
	else if (Dir == DIR_DOWN)//down
	{
		m_rct.MoveToY(m_rct.top + m_nSpeed);
	}
	else if (Dir == DIR_LEFT)//left
	{
		m_rct.MoveToX(m_rct.left - m_nSpeed);
	}
	else if (Dir == DIR_RIGHT)//right
	{
		m_rct.MoveToX(m_rct.left + m_nSpeed);
	}
}

