﻿
// FightingDlg.h: 头文件
//

#pragma once
#include "Tank.h"
#include"Shell.h"
#include"EneTank.h"
#include"EneShell.h"
#include<vector>
#include"ImgShow.h"
using namespace std;

// CFightingDlg 对话框
class CFightingDlg : public CDialogEx
{
// 构造
public:
	CFightingDlg(CWnd* pParent = nullptr);	// 标准构造函数

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_FIGHTING_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 支持

	Tank m_MyTank;
	vector<Shell>m_vecShell;
	vector<EneTank>m_vecTank;
	int EneNum = 0;
	int EneNumMax = 8;
	vector<EneShell>m_vecEneShell;
	ImgShow imgshow;
	

	//std::vector<Shell>m_vecShell;


// 实现
protected:
	HICON m_hIcon;

	// 生成的消息映射函数
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
//	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
//	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
};
