#pragma once
#include "Object.h"
class EneShell :public Object
{
public:
	EneShell(){}
	~EneShell() {};
public:
	void Show(CDC* pDC);
	void Create(CPoint pos, int nDir, int nSpeed);
protected:
	void UpdatePos();
	DWORD m_time;
	CRect m_iniRct;
};
