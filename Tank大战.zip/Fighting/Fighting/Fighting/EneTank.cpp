#define _CRT_RAND_S
#include "pch.h"
#include "EneTank.h"
#include<time.h>
#include"EneShell.h"

EneTank::EneTank(int EneNum) {
	m_rct = CRect(100 + EneNum * 40, 100, 130 + EneNum * 40, 130);
	m_nDir = 3;
	m_nSpeed = 1;
}

EneTank::~EneTank() {

}

EneTank EneTank::EneCreate(CRect rct, int EneNum) {
	m_rct = rct;
	EneTank t(EneNum);
	return t;
}

EneShell EneTank::EFire() {
	EneShell sh;
	CPoint pt = m_rct.CenterPoint();
	sh.Create(pt, m_nDir, m_nSpeed * 50);//�ڵ���ʼλ����̹��һ�£����з�����̹�˿��ڷ���һ�£��ٶȱ�̹�˿�

	return sh;
}

void EneTank::Show(CDC* pDC) {
	pDC->Rectangle(m_rct);
	pDC->MoveTo(m_rct.CenterPoint());
	if (m_nDir == DIR_UP)
		pDC->LineTo(m_rct.CenterPoint().x, m_rct.CenterPoint().y - 20);
	else if (m_nDir == DIR_DOWN)
		pDC->LineTo(m_rct.CenterPoint().x, m_rct.CenterPoint().y + 20);
	else if (m_nDir == DIR_LEFT)
		pDC->LineTo(m_rct.CenterPoint().x - 20, m_rct.CenterPoint().y);
	else if (m_nDir == DIR_RIGHT)
		pDC->LineTo(m_rct.CenterPoint().x + 20, m_rct.CenterPoint().y);
}

