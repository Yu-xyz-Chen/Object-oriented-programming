#pragma once

#include "Object.h"
#include"Shell.h"
#include"EneShell.h"
#include<vector>

using namespace std;

class EneTank :public Object
{
public:
	EneTank(int EneNum);
	~EneTank();

	int EneNum = 0;
	void Show(CDC* pDC);
	EneTank EneCreate(CRect rct, int EneNum);
	EneShell EFire();
};
