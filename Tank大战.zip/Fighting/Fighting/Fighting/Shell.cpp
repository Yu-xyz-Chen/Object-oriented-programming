#include "pch.h"
#include "Shell.h"

void Shell::Show(CDC* pDC) {
	UpdatePos();
	pDC->Ellipse(m_rct);
}

void Shell::UpdatePos() {
	DWORD tm = GetTickCount();
	int nDis = (tm - m_time) * m_nSpeed / 1000;
	switch (m_nDir) {
	case DIR_UP:
		m_rct.MoveToY(m_iniRct.top - nDis);
		break;
	case DIR_DOWN:
		m_rct.MoveToY(m_iniRct.top + nDis);
		break;
	case DIR_LEFT:
		m_rct.MoveToX(m_iniRct.left - nDis);
		break;
	case DIR_RIGHT:
		m_rct.MoveToX(m_iniRct.left + nDis);
		break;
	default:
		break;
	}
}

void Shell::Create(CPoint pos, int nDir, int nSpeed) {
	m_nDir = nDir;
	m_nSpeed = nSpeed;
	int nShellSize = 4;
	m_rct = CRect(pos.x - nShellSize, pos.y - nShellSize, pos.x + nShellSize, pos.y + nShellSize);
	m_iniRct = m_rct;
	m_time = GetTickCount();
}