#pragma once
#include "ETank.h"
//class ImgEtank :
//	public ETank
//{
//protected:
//	CImage m_img;
//public:
//	void Show(CDC* pDC);
//	bool LoadImg();
//};

