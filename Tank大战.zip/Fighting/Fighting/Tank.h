#pragma once
#include "Object.h"
#include "Shell.h"
class Tank:public Object
{
public:

	Tank();
	~Tank();
	void Show(CDC* pDC);
	Shell Fire();
	
protected:
	CImage m_img[4];
};