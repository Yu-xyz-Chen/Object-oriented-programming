#include "pch.h"
#include "Imgwall.h"
void Imgwall::Show(CDC* pDC)
{
	if (!m_img.IsNull())
	{
		CRect rct(m_wall.CenterPoint().x - 10, m_wall.CenterPoint().y - 10, m_wall.CenterPoint().x + 10, m_wall.CenterPoint().y + 10);
		m_img.Draw(pDC->GetSafeHdc(), rct, Gdiplus::InterpolationModeHighQuality);


	}

}
bool Imgwall::LoadImg()
{
	m_img.Load(L"wall.gif");
	if (m_img.IsNull())
		return false;
	return true;
}